public class Alphabet {
    public static final int R = 256;
}